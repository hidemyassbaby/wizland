M3U8_URL = 'https://i.mjh.nz/nz/tv.json.gz'
EPG_URL = 'https://i.mjh.nz/nz/epg.xml.gz'

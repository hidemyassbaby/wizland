HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36',
    'Accept': 'application/json',
    'X-Forwarded-For' : '202.89.4.222',
}

API_URL = 'https://play.stuff.co.nz/proxy{}'

UUID  = '5b04524e-3d88-41a0-bb06-f81c30ed5cc3'
APPID = '5cd25a3e1de1c4001c728977'
LOCALE = 'en'

BRIGHTCOVE_URL     = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/{}'
BRIGHTCOVE_KEY     = 'BCpkADawqM3KfgdNYZ0Y7EWNjlastBDaiqfYCwjFesnSvtpP1SZJsutJNIVeME0BzpCPdI1U_Ux0mWRQ1_fu2Rv67E3yMgf6X4e3_9sdWPy72XjVP0mSTxjSI00cXResb0gKOZ33Ajp-1juF'
BRIGHTCOVE_ACCOUNT = '6005208634001'
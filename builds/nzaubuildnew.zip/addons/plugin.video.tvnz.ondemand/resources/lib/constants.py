HEADERS = {
    'User-Agent': 'Android/Ondemand/609',
    'x-tvnz-api-client-id': 'androidphone/2.64.3.609',
    'X-Forwarded-For' : '202.89.4.222',
}

API_URL = 'https://apis-public-prod.tech.tvnz.co.nz{}'
IMG_BASE = 'https://api.tvnz.co.nz{}'
PAGE_LIMIT = 4

BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/{}'
BRIGHTCOVE_KEY = 'BCpkADawqM0IurzupiJKMb49WkxM__ngDMJ3GOQBhN2ri2Ci_lHwDWIpf4sLFc8bANMc-AVGfGR8GJNgxGqXsbjP1gHsK2Fpkoj6BSpwjrKBnv1D5l5iGPvVYCo'
BRIGHTCOVE_ACCOUNT = '963482467001'

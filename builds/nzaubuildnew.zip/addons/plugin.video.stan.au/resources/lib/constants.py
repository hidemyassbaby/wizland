HEADERS = {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; SHIELD Android TV Build/PPR1.180610.011)',
}

API_URL = 'https://api.stan.com.au{}'
ACTIVATE_URL = 'https://www.stan.com.au/activate'
STAN_NAME = 'Stan-AndroidTV'

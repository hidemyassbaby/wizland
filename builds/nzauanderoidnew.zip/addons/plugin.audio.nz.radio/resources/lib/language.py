from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    STATIONS  = 30000

_ = Language()
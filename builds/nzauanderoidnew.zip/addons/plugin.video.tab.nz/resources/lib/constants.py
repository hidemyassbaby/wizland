HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
    'Origin': 'https://www.tab.co.nz',
    'Referer': 'https://www.tab.co.nz/',
}

EPG_URL = 'https://i.mjh.nz/nz/epg.xml.gz'

from resources.lib import service

service.start()